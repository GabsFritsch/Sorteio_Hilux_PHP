CREATE TABLE `toyota`.`toyota` (
  `codigo` INT NOT NULL AUTO_INCREMENT,
  `nome` VARCHAR(45) NULL,
  `telefone` VARCHAR(20) NULL,
  PRIMARY KEY (`codigo`),
  UNIQUE INDEX `telefone_UNIQUE` (`telefone` ASC));